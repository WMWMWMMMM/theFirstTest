package com.sy.dormitorysystemspring.controller;

import com.sy.dormitorysystemspring.pojo.Dorm;
import com.sy.dormitorysystemspring.pojo.DormManage;
import com.sy.dormitorysystemspring.service.DormManageService;
import com.sy.dormitorysystemspring.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("dormManage")
public class DormManagerController {
    @Autowired
    private DormManageService dormManageService;

    @RequestMapping("/add")
    public Result add(@RequestBody DormManage dormManage) {
        return dormManageService.add(dormManage);
    }

    @RequestMapping("/delete")
    public Result delete(Long id) {
        return dormManageService.delete(id);
    }

    @RequestMapping("/select")
    public Result select(Long id) { 
        return dormManageService.select(id);
    }

    @RequestMapping("/update")
    public Result update(@RequestBody DormManage dormManage) {
        return dormManageService.myUpdate(dormManage);

    }
}
