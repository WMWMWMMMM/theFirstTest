package com.sy.dormitorysystemspring.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sy.dormitorysystemspring.pojo.Admin;
import com.sy.dormitorysystemspring.service.AdminService;
import com.sy.dormitorysystemspring.mapper.AdminMapper;
import com.sy.dormitorysystemspring.utils.JwtHelper;
import com.sy.dormitorysystemspring.utils.MD5Util;
import com.sy.dormitorysystemspring.utils.Result;
import com.sy.dormitorysystemspring.utils.ResultCodeEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
* @author 幻
* @description 针对表【admin】的数据库操作Service实现
* @createDate 2024-05-18 03:29:51
*/
@Service
public class AdminServiceImpl extends ServiceImpl<AdminMapper, Admin>
    implements AdminService{
    @Autowired
    private AdminMapper adminMapper;
    @Autowired
    private JwtHelper jwtHelper;
    @Override
    public Result login(String password) {
        //账号密码验证
        LambdaQueryWrapper<Admin> queryWrapperp = new LambdaQueryWrapper<>();
        queryWrapperp.eq(Admin::getId, 1);
        Admin admin = adminMapper.selectOne(queryWrapperp);
        System.out.println(admin.getPassword());
        System.out.println(MD5Util.encrypt(password));
        if (admin.getPassword().equals(MD5Util.encrypt(password))) {
            //账号密码正确
            //根据用户唯一标识生成token
            String token = jwtHelper.createToken(Long.valueOf(8848));
            Map data = new HashMap();
            data.put("token", token);
            return Result.ok(data);
        }
        return Result.build(null, ResultCodeEnum.PASSWORD_ERROR);
    }

}




