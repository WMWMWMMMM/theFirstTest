package com.sy.dormitorysystemspring.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sy.dormitorysystemspring.mapper.StudentMapper;
import com.sy.dormitorysystemspring.pojo.Order;
import com.sy.dormitorysystemspring.pojo.Student;
import com.sy.dormitorysystemspring.service.OrderService;
import com.sy.dormitorysystemspring.mapper.OrderMapper;
import com.sy.dormitorysystemspring.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
* @author 幻
* @description 针对表【order】的数据库操作Service实现
* @createDate 2024-05-18 03:29:52
*/
@Service
public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order>
    implements OrderService{
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private StudentMapper  studentMapper;
    @Override
    public Result add(Order order) {
        Long id  = order.getStudentId();
        Student student = studentMapper.selectById(id);
        if(student==null) {
            return Result.error("学生不存在");
        }
        order.setId(null);
        orderMapper.insert(order);
        return Result.ok(null);
    }

    @Override
    public Result update(Order order) {
        Order oldOrder = orderMapper.selectById(order.getId());
        if(oldOrder==null) {
            return Result.error("订单不存在");
        }
        Student studnet = studentMapper.selectById(order.getStudentId());
        if(studnet == null){
            return Result.error("学生不存在");
        }
        orderMapper.updateById(order);
        return Result.ok(null);
    }
}




