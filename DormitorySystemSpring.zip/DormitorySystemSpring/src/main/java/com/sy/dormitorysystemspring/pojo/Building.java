package com.sy.dormitorysystemspring.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;

/**
 * @TableName building
 */
@TableName(value ="building")
@Data
public class Building implements Serializable {
    private Long id;

    private Integer dormNum;

    private String address;

    private Integer gender;

    private String name;

    private static final long serialVersionUID = 1L;
}