package com.sy.dormitorysystemspring.pojo;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * @TableName student
 */
@TableName(value ="student")
@Data
public class Student implements Serializable {
    @TableId
    private Long id;

    private String password;

    private String name;

    private String identificationNumber;

    private Date birth;

    private String origin;

    private String telephone;

    private String professional;

    private Integer status;

    private Integer gender;

    private Long dormId;
    @Version
    @JsonIgnore
    private Integer version = 1;

    @TableLogic(value = "0", delval = "1")
    @JsonIgnore
    private Integer isDeleted = 0;

    private static final long serialVersionUID = 1L;
}