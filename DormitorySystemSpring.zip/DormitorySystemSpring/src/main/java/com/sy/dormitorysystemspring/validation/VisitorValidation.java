package com.sy.dormitorysystemspring.validation;

import com.sy.dormitorysystemspring.pojo.Visitor;

import java.util.Date;

public class VisitorValidation {
    boolean isValid(Visitor visitor) {
        Long id = visitor.getId();
        if (id < 1 || id == null) {
            return false;
        }
        String name = visitor.getName();
        if (name == null || name.trim().length() == 0) {
            return false;
        }
        Integer gender = visitor.getGender();
        if (gender == null || (gender!= 0 && gender!= 1)) {
            return false;
        }
        Date startDay = visitor.getStartDay();
        if (startDay == null) {
            return false;
        }
        Date endDay = visitor.getEndDay();
        if (endDay == null) {
            return false;
        }
        String cause = visitor.getCause();
        if (cause == null || cause.trim().length() == 0) {
            return false;
        }
        Long studentId = visitor.getStudentId();
        if (studentId == null || studentId <= 0) {
            return false;
        }
        return true;
    }
}
