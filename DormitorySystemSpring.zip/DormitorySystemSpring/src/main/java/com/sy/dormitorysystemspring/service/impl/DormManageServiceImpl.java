package com.sy.dormitorysystemspring.service.impl;

import com.alibaba.druid.util.StringUtils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sy.dormitorysystemspring.mapper.SchedulingMapper;
import com.sy.dormitorysystemspring.pojo.DormManage;
import com.sy.dormitorysystemspring.pojo.Scheduling;
import com.sy.dormitorysystemspring.service.DormManageService;
import com.sy.dormitorysystemspring.mapper.DormManageMapper;
import com.sy.dormitorysystemspring.utils.JwtHelper;
import com.sy.dormitorysystemspring.utils.MD5Util;
import com.sy.dormitorysystemspring.utils.Result;
import com.sy.dormitorysystemspring.utils.ResultCodeEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
* @author 幻
* @description 针对表【dorm_manage】的数据库操作Service实现
* @createDate 2024-05-18 03:29:51
*/
@Service
public class DormManageServiceImpl extends ServiceImpl<DormManageMapper, DormManage>
    implements DormManageService{
    @Autowired
    private DormManageMapper dormManageMapper;
    @Autowired
    private JwtHelper jwtHelper;
    @Autowired
    private SchedulingMapper  schedulingMapper;
    @Override
    public Result login(Long id, String password) {
        //账号密码验证
        LambdaQueryWrapper<DormManage> queryWrapperp = new LambdaQueryWrapper<>();
        queryWrapperp.eq(DormManage::getId, id);
        DormManage dormManage = dormManageMapper.selectOne(queryWrapperp);
        if (dormManage == null) {
            return Result.build(null, ResultCodeEnum.USERNAME_ERROR);
        }
        if (!StringUtils.isEmpty(password) && dormManage.getPassword().equals(MD5Util.encrypt(password))) {
            //账号密码正确
            //根据用户唯一标识生成token
            String token = jwtHelper.createToken(Long.valueOf(dormManage.getId()));
            Map data = new HashMap();
            data.put("token", token);
            return Result.ok(data);
        }
        return Result.build(null, ResultCodeEnum.NOTLOGIN);
    }
    @Override
    public Result add(DormManage dormManage) {
        if(dormManage.getGender()!=0){
            return Result.error("不允许非女性舍管");
        }
        dormManageMapper.insert(dormManage);
        return Result.ok(null);
    }
    @Override
    public Result select(Long id){
        DormManage dormManage = dormManageMapper.selectById(id);
        dormManage.setPassword(null);
        return Result.ok(dormManage);
    }
    @Override
    public Result delete(Long id){
        dormManageMapper.deleteById(id);
        return Result.ok(null);
    }
    @Override
    public Result myUpdate(DormManage dormManage) {
        if(dormManage.getGender()!=0){
            return Result.error("不允许非女性舍管");
        }
        Long id = dormManage.getId();
        Scheduling scheduling = schedulingMapper.selectById(id);
        if (scheduling == null) {
            dormManageMapper.updateById(dormManage);
            return Result.ok(null);
        }
       return Result.build(null, ResultCodeEnum.ERROR);
    }

}




