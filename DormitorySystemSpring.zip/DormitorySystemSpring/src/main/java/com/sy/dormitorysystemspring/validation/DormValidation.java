package com.sy.dormitorysystemspring.validation;

import com.sy.dormitorysystemspring.pojo.Dorm;

public class DormValidation {
    boolean isValidDorm(Dorm dorm) {
        Long id = dorm.getId();
        if (id <= 1000 || id >= 9999) {
            return false;
        }
        Integer personNum = dorm.getPersonNum();
        if (personNum > 6 || personNum < 1) {
            return false;
        }
        String address = dorm.getAddress();
        if (address.length() > 20 || address.length() < 1) {
            return false;
        }
        Long buildingId = dorm.getBuildingId();
        if (buildingId < 1 || buildingId > 1000) {
            return false;
        }
        Integer type = dorm.getType();
        if (type < 1 || type > 10) {
            return false;
        }
        Integer gender = dorm.getGender();
        if (gender < 1 || gender > 2) {
            return false;
        }
        return true;
    }
}
