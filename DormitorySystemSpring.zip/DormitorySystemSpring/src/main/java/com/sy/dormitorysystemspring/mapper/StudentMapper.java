package com.sy.dormitorysystemspring.mapper;

import com.sy.dormitorysystemspring.pojo.Student;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Select;

/**
* @author 幻
* @description 针对表【student】的数据库操作Mapper
* @createDate 2024-05-18 03:39:44
* @Entity com.sy.dormitorysystemspring.pojo.Student
*/
public interface StudentMapper extends BaseMapper<Student> {
    @Select("SELECT * FROM student WHERE id = #{id} and isDeleted = 1")
    Student selectIsDetele(Integer id);

}




