package com.sy.dormitorysystemspring.service;

import com.sy.dormitorysystemspring.pojo.DormManage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sy.dormitorysystemspring.utils.Result;

/**
* @author 幻
* @description 针对表【dorm_manage】的数据库操作Service
* @createDate 2024-05-18 03:29:51
*/
public interface DormManageService extends IService<DormManage> {

    Result login(Long id, String password);

    Result add(DormManage dormManage);

    Result select(Long id);

    Result delete(Long id);

    Result myUpdate(DormManage dormManage);
}
