package com.sy.dormitorysystemspring.pojo;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * @TableName dorm_manage
 */
@TableName(value ="dorm_manage")
@Data
public class DormManage implements Serializable {
    @TableId(type = IdType.AUTO)
    private Long id;

    private String password;

    private String name;

    private Integer gender;

    private String identificationNumber;

    private Date birth;

    private String origin;

    private String telephone;

    private Date entryDay;
    @Version
    @JsonIgnore
    private Integer version = 1;
    @TableLogic(value = "0", delval = "1")
    @JsonIgnore
    private Integer idDeleted = 0;

    private static final long serialVersionUID = 1L;
}