package com.sy.dormitorysystemspring.validation;

import com.sy.dormitorysystemspring.pojo.Order;
import com.sy.dormitorysystemspring.pojo.Scheduling;

import java.util.Date;

public class SchedulingValidation {
    boolean isValid(Scheduling scheduling) {
        Long id = scheduling.getId();
        if (scheduling.getId() < 1) {
            return false;
        }
        Long dormManageId = scheduling.getDormManageId();
        if (scheduling.getDormManageId() <1) {
            return false;
        }
        Long buildingId = scheduling.getBuildingId();
        if (scheduling.getBuildingId() <1) {
            return false;
        }
        Date startTime = scheduling.getStartTime();
        if (startTime == null) {
            return false;
        }
        Date endTime = scheduling.getEndTime();
        if (startTime == null || endTime == null) {
            return false;
        }
        return true;
    }
}
