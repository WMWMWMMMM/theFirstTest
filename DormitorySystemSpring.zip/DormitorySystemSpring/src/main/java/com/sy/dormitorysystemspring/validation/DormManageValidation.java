package com.sy.dormitorysystemspring.validation;

import com.sy.dormitorysystemspring.pojo.DormManage;

import java.util.Date;

public class DormManageValidation {
    boolean validate(DormManage dormManage){
        Long id = dormManage.getId();
        if(id == null||id < 1||id >10000){
            return false;
        }
        String password = dormManage.getPassword();
        if(password == null ||password.length() < 6|| password.length() > 20){
            return false;
        }
        String name = dormManage.getName();
        if(name == null){
            return false;
        }
        Integer gender = dormManage.getGender();
        if(gender == null ||gender != 0 && gender!= 1){
            return false;
        }
        String identificationNumber = dormManage.getIdentificationNumber();
        if(identificationNumber.length() != 18){
            return false;
        }
        Date birth = dormManage.getBirth();
        Date now = new Date();
        if(birth == null|| birth.after(now)){
            return false;
        }
        String origin = dormManage.getOrigin();
        if(origin.length() < 1 || origin.length() > 100){
            return false;
        }
        String telephone = dormManage.getTelephone();
        if(telephone.length() != 11){
            return false;
        }
        Date entryDay = dormManage.getEntryDay();
        if(entryDay == null){
            return false;
        }
        return true;
    }
}
