package com.sy.dormitorysystemspring.controller;

import com.sy.dormitorysystemspring.pojo.Student;
import com.sy.dormitorysystemspring.pojo.Visitor;
import com.sy.dormitorysystemspring.service.StudentService;
import com.sy.dormitorysystemspring.service.VisitorService;
import com.sy.dormitorysystemspring.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/visitor")
public class VisitorController {

    @Autowired
    private VisitorService visitorService;

    @RequestMapping("/add")
    public Result add(@RequestBody Visitor visitor) {
        visitorService.add(visitor);
        return Result.ok(null);
    }

    @RequestMapping("/delete")
    public Result delete(String id) {
        visitorService.removeById(id);
        return Result.ok(null);
    }
    @RequestMapping("/select")
    public Result get(String id){
        visitorService.getById(id);
        return Result.ok(null);
    }
    @RequestMapping("/update")
    public Result update(@RequestBody Visitor visitor) {
        visitorService.myUpdate(visitor);
        return Result.ok(null);
    }
}
