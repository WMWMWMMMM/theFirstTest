package com.sy.dormitorysystemspring.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.sy.dormitorysystemspring.utils.JwtHelper;
import com.sy.dormitorysystemspring.utils.MD5Util;
import com.sy.dormitorysystemspring.utils.Result;
import com.sy.dormitorysystemspring.utils.ResultCodeEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

//@SuppressWarnings("all")
@Service
public class UserServiceImpl{
/**
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private JwtHelper jwtHelper;
/**
    @Override
    public Result getUserInfo(String token){
        //token验证
        if(jwtHelper.isExpiration(token)){
            return Result.build(null, ResultCodeEnum.NOTLOGIN);
        }
        int userId = jwtHelper.getUserId(token).intValue();
        User user = userMapper.selectById(userId);
        if(user!=null){
            user.setUserPwd(null);
            Map data = new HashMap();
            data.put("loginUser",user);
            return Result.ok(data);
        }
        return Result.build(null,ResultCodeEnum.NOTLOGIN);
    }

    @Override
    public Result checkUserName(String username){
        //用户名是否重复验证
        LambdaQueryWrapper<User> queryWrapperp = new LambdaQueryWrapper<>();
        queryWrapperp.eq(User::getUsername,username);
        User loginUser = userMapper.selectOne(queryWrapperp);
        if(loginUser!=null){
            return Result.build(null,ResultCodeEnum.USERNAME_USED);
        }
        return Result.ok(null);
    }

    @Override
    public Result regist(User user){
        //用户注册
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUsername,user.getUsername());
        Long count = userMapper.selectCount(queryWrapper);
        if(count>0){
            return Result.build(null,ResultCodeEnum.USERNAME_USED);
        }
        user.setUserPwd(MD5Util.encrypt(user.getUserPwd()));
        int rows = userMapper.insert(user);
        return Result.ok(null);
    }
    */
}




