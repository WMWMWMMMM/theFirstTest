package com.sy.dormitorysystemspring.config;

import com.sy.dormitorysystemspring.interceptors.LoginProtectInterceptor;
import com.sy.dormitorysystemspring.interceptors.LoginProtectInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMVCConfig implements WebMvcConfigurer {
    @Autowired
    private LoginProtectInterceptor loginProtectInterceptor;

    @Override
    //配置拦截器
    public void addInterceptors(InterceptorRegistry registry) {
        String[] paths = {"/dorm/**", "/dormManager/**", "/order/**", "/student/**", "/visitor/**"};
        registry.addInterceptor(loginProtectInterceptor).addPathPatterns(paths);
    }
}
