package com.sy.dormitorysystemspring.controller;


import com.sy.dormitorysystemspring.service.DormManageService;
import com.sy.dormitorysystemspring.service.AdminService;
import com.sy.dormitorysystemspring.service.StudentService;
import com.sy.dormitorysystemspring.utils.JwtHelper;
import com.sy.dormitorysystemspring.utils.Result;
import com.sy.dormitorysystemspring.utils.ResultCodeEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private JwtHelper jwtHelper;
    @Autowired
    private StudentService studentService;
    @Autowired
    private AdminService adminService;
    @Autowired
    private DormManageService dormManageService;

    @RequestMapping("/hello")
    public String hello() {
        return "hello";
    }

    //宿管和管理员登录
    @PostMapping("/login")
    public Result login(String username, String password) {
        Result result;
        if (username.equals("root")) {
            result = adminService.login(password);
            return result;
        }
        Long id = Long.parseLong(username);
        result = dormManageService.login(id, password);
        return result;
    }
/**
 //检验获取信息

 //检查名字是否重复
 @PostMapping("checkUserName") public Result checkUserName(@RequestHeader String username){
 Result result = userService.checkUserName(username);
 return result;
 }
 注册
 @PostMapping("regist") public Result regist(@RequestBody User user){
 Result result = userService.regist(user);
 return result;
 }
 @GetMapping("checkLogin") public Result checkLogin(@RequestHeader String token){
 boolean expiration = jwtHelper.isExpiration(token);
 if(expiration){
 return Result.build(null, ResultCodeEnum.NOTLOGIN);
 }

 return Result.ok(null);
 }
 */
}
