package com.sy.dormitorysystemspring.utils;

public enum Status {
    TEST1("a","teset"),Summer("b","teset"),Autumn("c","teset");
    private String test;
    private String test2;

    Status(String a, String teset) {

    }
}
