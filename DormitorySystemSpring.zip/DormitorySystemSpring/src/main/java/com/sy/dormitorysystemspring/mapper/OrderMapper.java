package com.sy.dormitorysystemspring.mapper;

import com.sy.dormitorysystemspring.pojo.Order;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 幻
* @description 针对表【order】的数据库操作Mapper
* @createDate 2024-05-18 03:29:52
* @Entity com.sy.dormitorysystemspring.pojo.Order
*/
public interface OrderMapper extends BaseMapper<Order> {

}




