package com.sy.dormitorysystemspring.mapper;

import com.sy.dormitorysystemspring.pojo.Building;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 幻
* @description 针对表【building】的数据库操作Mapper
* @createDate 2024-05-18 03:29:52
* @Entity com.sy.dormitorysystemspring.pojo.Building
*/
public interface BuildingMapper extends BaseMapper<Building> {

}




