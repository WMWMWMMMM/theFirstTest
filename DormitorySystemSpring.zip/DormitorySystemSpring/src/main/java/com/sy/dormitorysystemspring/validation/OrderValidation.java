package com.sy.dormitorysystemspring.validation;

import com.sy.dormitorysystemspring.pojo.Order;

import java.util.Date;

public class OrderValidation {
    boolean isValid(Order order) {
        Long id = order.getId();
        if (id <= 1) {
            return false;
        }
        String type = order.getType();
        if (type == null) {
            return false;
        }
        Long studentId = order.getStudentId();
        if (studentId < 10000 || studentId > 99999) {
            return false;
        }
        Integer amount = order.getAmount();
        if (amount == null) {
            return false;
        }
        Date time = order.getTime();
        if (time == null) {
            return false;
        }
        Integer status = order.getStatus();
        if (status == null) {
            return false;
        }
        return true;
    }
}
