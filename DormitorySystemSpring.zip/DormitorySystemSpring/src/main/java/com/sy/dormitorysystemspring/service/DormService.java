package com.sy.dormitorysystemspring.service;

import com.sy.dormitorysystemspring.pojo.Dorm;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sy.dormitorysystemspring.utils.Result;

/**
* @author 幻
* @description 针对表【dorm】的数据库操作Service
* @createDate 2024-05-18 03:29:52
*/
public interface DormService extends IService<Dorm> {
    Result add(Dorm dorm);

    Result delete(Long id);

    Result update(Dorm dorm);

    Result select(Long id);


}
