package com.sy.dormitorysystemspring.controller;

import com.sy.dormitorysystemspring.pojo.Dorm;
import com.sy.dormitorysystemspring.service.DormService;
import com.sy.dormitorysystemspring.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/dorm")
public class DormController {

    @Autowired
    private DormService dormService;
    @RequestMapping("/add")
    public Result add(@RequestBody Dorm dorm) {
        return dormService.add(dorm);
    }

    @RequestMapping("/delete")
    public Result delete(Long id) {
        return dormService.delete(id);
    }
    @RequestMapping("/select")
    public Result select(Long id){
        return dormService.select(id);
    }
    @RequestMapping("/update")
    public Result update(@RequestBody Dorm dorm) {
        return dormService.update(dorm);
    }
}
