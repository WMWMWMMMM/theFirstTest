package com.sy.dormitorysystemspring.service;

import com.sy.dormitorysystemspring.pojo.Student;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sy.dormitorysystemspring.utils.Result;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
* @author 幻
* @description 针对表【student】的数据库操作Service
* @createDate 2024-05-18 03:39:44
*/
public interface StudentService extends IService<Student> {

    @Transactional
    Result add(Student student);


    Result select(Long userId);

    @Transactional
    Result selectAll();

    @Transactional
    Result myUpdate(Student student);

    @Transactional
    Result deleteById(Long userId);
}
