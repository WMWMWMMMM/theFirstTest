package com.sy.dormitorysystemspring.mapper;

import com.sy.dormitorysystemspring.pojo.DormManage;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 幻
* @description 针对表【dorm_manage】的数据库操作Mapper
* @createDate 2024-05-18 03:29:51
* @Entity com.sy.dormitorysystemspring.pojo.DormManage
*/
public interface DormManageMapper extends BaseMapper<DormManage> {

}




