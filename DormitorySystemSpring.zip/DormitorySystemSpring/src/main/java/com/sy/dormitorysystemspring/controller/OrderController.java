package com.sy.dormitorysystemspring.controller;

import com.sy.dormitorysystemspring.pojo.Order;
import com.sy.dormitorysystemspring.pojo.Student;
import com.sy.dormitorysystemspring.service.OrderService;
import com.sy.dormitorysystemspring.service.StudentService;
import com.sy.dormitorysystemspring.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @RequestMapping("/add")
    public Result add(@RequestBody Order order) {
        return orderService.add(order);
    }

    @RequestMapping("/delete")
    public Result delete(String id) {
        boolean key = orderService.removeById(id);
        if(!key){
            return Result.error("删除失败");
        }
        return Result.ok(null);
    }

    @RequestMapping("/select")
    public Result select(String id) {
        Order order = orderService.getById(id);
        return Result.ok(order);
    }

    @RequestMapping("/update")
    public Result update(@RequestBody Order order) {
        orderService.update(order);
        return Result.ok(null);
    }
}
