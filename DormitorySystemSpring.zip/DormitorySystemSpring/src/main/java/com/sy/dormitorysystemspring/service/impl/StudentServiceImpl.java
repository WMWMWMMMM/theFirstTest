package com.sy.dormitorysystemspring.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sy.dormitorysystemspring.mapper.DormMapper;
import com.sy.dormitorysystemspring.mapper.OrderMapper;
import com.sy.dormitorysystemspring.pojo.Dorm;
import com.sy.dormitorysystemspring.pojo.Order;
import com.sy.dormitorysystemspring.pojo.Student;
import com.sy.dormitorysystemspring.service.StudentService;
import com.sy.dormitorysystemspring.mapper.StudentMapper;
import com.sy.dormitorysystemspring.utils.JwtHelper;
import com.sy.dormitorysystemspring.utils.Result;
import com.sy.dormitorysystemspring.utils.ResultCodeEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
* @author 幻
* @description 针对表【student】的数据库操作Service实现
* @createDate 2024-05-18 03:39:44
*/
@Service
public class StudentServiceImpl extends ServiceImpl<StudentMapper, Student>
    implements StudentService{
    @Autowired
    private StudentMapper studentMapper;
    @Autowired
    private JwtHelper jwtHelper;
    @Autowired
    private DormMapper dormMapper;
    @Autowired
    private OrderMapper orderMapper;


    @Override
    @Transactional(rollbackFor = Exception.class,isolation = Isolation.READ_COMMITTED)
    public Result add(Student student) {
        //添加学生
        Dorm dorm = dormMapper.selectById(student.getDormId());
        if (dorm != null && dorm.getPersonNum() + 1 <= dorm.getType() && dorm.getGender() == student.getGender()) {
            dorm.setPersonNum(dorm.getPersonNum() + 1);
            dormMapper.updateById(dorm);
            studentMapper.insert(student);
            return Result.ok(null);
        }
        return Result.build(null,500,"error");
    }


    @Override
    public Result select(Long userId) {
        Student student = studentMapper.selectById(userId);
        if (student != null) {
            student.setPassword(null);
            return Result.ok(student);
        }
        return Result.error("未查询到学生信息");
    }

    @Override
    @Transactional(rollbackFor = Exception.class,isolation = Isolation.READ_COMMITTED)
    public Result selectAll() {
        List<Student> students = studentMapper.selectList(null);
        for (Student student : students) {
            student.setPassword(null);
        }
        return Result.ok(students);
    }

    @Override
    @Transactional(rollbackFor = Exception.class,isolation = Isolation.READ_COMMITTED)
    public Result myUpdate(Student student) {
        if (student == null) {
            Result.build(null, ResultCodeEnum.ERROR);
        }
        Student oldStudent = studentMapper.selectById(student.getId());
        if (oldStudent == null) {
            Result.build(null, ResultCodeEnum.ERROR);
        }
        if (oldStudent.getDormId() == student.getDormId()) {
            studentMapper.updateById(student);
            Result.build(null, ResultCodeEnum.ERROR);
        }
        if (student.getDormId() != null && student.getDormId() != oldStudent.getDormId()) {
            Dorm oldDorm = dormMapper.selectById(oldStudent.getDormId());
            Dorm newDorm = dormMapper.selectById(student.getDormId());
            if (newDorm != null) {
                oldDorm.setPersonNum(oldDorm.getPersonNum() - 1);
                newDorm.setPersonNum(newDorm.getPersonNum() + 1);
                dormMapper.updateById(oldDorm);
                dormMapper.updateById(newDorm);
                studentMapper.updateById(student);
                return Result.ok(null);
            }
        }
        return Result.build(null, ResultCodeEnum.ERROR);
    }

    @Override
    @Transactional(rollbackFor = Exception.class,isolation = Isolation.READ_COMMITTED)
    public Result deleteById(Long userId){
        Student student = studentMapper.selectById(userId);
        if(student!=null){
            LambdaQueryWrapper<Order> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Order::getStudentId,userId).eq(Order::getStatus,"0");
            List<Order> orders = orderMapper.selectList(wrapper);
            if(orders.size()>0){
                Result.build(null, ResultCodeEnum.ERROR);
            }
            Dorm dorm = dormMapper.selectById(student.getDormId());
            dorm.setPersonNum(dorm.getPersonNum() - 1);
            dormMapper.updateById(dorm);
            studentMapper.deleteById(userId);
            return Result.ok(null);
        }
        return Result.build(null, ResultCodeEnum.ERROR);
    }

}




