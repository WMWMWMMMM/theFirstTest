package com.sy.dormitorysystemspring.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sy.dormitorysystemspring.pojo.Scheduling;
import com.sy.dormitorysystemspring.service.SchedulingService;
import com.sy.dormitorysystemspring.mapper.SchedulingMapper;
import org.springframework.stereotype.Service;

/**
* @author 幻
* @description 针对表【scheduling】的数据库操作Service实现
* @createDate 2024-05-18 12:50:09
*/
@Service
public class SchedulingServiceImpl extends ServiceImpl<SchedulingMapper, Scheduling>
    implements SchedulingService{

}




