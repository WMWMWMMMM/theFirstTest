package com.sy.dormitorysystemspring.mapper;

import com.sy.dormitorysystemspring.pojo.Dorm;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sy.dormitorysystemspring.pojo.Student;
import org.apache.ibatis.annotations.Select;

/**
* @author 幻
* @description 针对表【dorm】的数据库操作Mapper
* @createDate 2024-05-18 03:29:52
* @Entity com.sy.dormitorysystemspring.pojo.Dorm
*/
public interface DormMapper extends BaseMapper<Dorm> {
    @Select("SELECT * FROM dorm WHERE id = #{id} and is_deleted = 1")
    Dorm selectIsDelete(Long id);
}



