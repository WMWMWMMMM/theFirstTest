package com.sy.dormitorysystemspring.pojo;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * @TableName visitor
 */
@TableName(value ="visitor")
@Data
public class Visitor implements Serializable {
    @TableId(type = IdType.AUTO)
    private Long id;

    private String name;

    private Integer gender;

    private Date startDay;

    private Date endDay;

    private String cause;

    private Long studentId;
    @Version
    @JsonIgnore
    private Integer version = 1;
    @TableLogic(value = "0", delval = "1")
    @JsonIgnore
    private Integer isDeleted = 0;

    private static final long serialVersionUID = 1L;
}