package com.sy.dormitorysystemspring.interceptors;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sy.dormitorysystemspring.utils.JwtHelper;
import com.sy.dormitorysystemspring.utils.Result;
import com.sy.dormitorysystemspring.utils.ResultCodeEnum;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class LoginProtectInterceptor implements HandlerInterceptor {
    @Autowired
    private JwtHelper jwtHelper;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (request.getHeader("token") == null) {
            return true;
        }
        //获取token
        String token = request.getHeader("token");

        //判断token是否过期
        boolean expiration = jwtHelper.isExpiration(token);
        if (!expiration) {    //token未过期
            return true;
        }
        Result result = Result.build(null, ResultCodeEnum.NOTLOGIN);
        String json = new ObjectMapper().writeValueAsString(result); //序列化为json字符串
        response.getWriter().write(json);
        return false;
    }

}
