package com.sy.dormitorysystemspring.pojo;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * @TableName dorm
 */
@TableName(value ="dorm")
@Data
public class Dorm implements Serializable {
    private Long id;

    private Integer personNum;

    private String address;

    private Long buildingId;

    private Integer type;

    private Integer gender;
    @Version
    @JsonIgnore
    private Integer version = 1;
    @TableLogic(value = "0", delval = "1")
    @JsonIgnore
    private Integer isDeleted = 0;

    private static final long serialVersionUID = 1L;
}