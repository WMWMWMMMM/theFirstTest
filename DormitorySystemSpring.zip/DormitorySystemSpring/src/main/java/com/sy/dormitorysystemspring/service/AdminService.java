package com.sy.dormitorysystemspring.service;

import com.sy.dormitorysystemspring.pojo.Admin;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sy.dormitorysystemspring.utils.Result;

/**
* @author 幻
* @description 针对表【admin】的数据库操作Service
* @createDate 2024-05-18 03:29:51
*/
public interface AdminService extends IService<Admin> {

    Result login(String password);
}
