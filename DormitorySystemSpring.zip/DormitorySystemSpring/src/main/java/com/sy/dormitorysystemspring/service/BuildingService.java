package com.sy.dormitorysystemspring.service;

import com.sy.dormitorysystemspring.pojo.Building;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 幻
* @description 针对表【building】的数据库操作Service
* @createDate 2024-05-18 03:29:52
*/
public interface BuildingService extends IService<Building> {

}
