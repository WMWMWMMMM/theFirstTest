package com.sy.dormitorysystemspring.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sy.dormitorysystemspring.mapper.StudentMapper;
import com.sy.dormitorysystemspring.pojo.Building;
import com.sy.dormitorysystemspring.pojo.Dorm;
import com.sy.dormitorysystemspring.pojo.Student;
import com.sy.dormitorysystemspring.service.BuildingService;
import com.sy.dormitorysystemspring.service.DormService;
import com.sy.dormitorysystemspring.mapper.DormMapper;
import com.sy.dormitorysystemspring.service.StudentService;
import com.sy.dormitorysystemspring.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 幻
 * @description 针对表【dorm】的数据库操作Service实现
 * @createDate 2024-05-18 03:29:52
 */
@Service
public class DormServiceImpl extends ServiceImpl<DormMapper, Dorm>
        implements DormService {
    @Autowired
    private BuildingService buildingService;
    @Autowired
    private StudentMapper studnetMapper;
    @Autowired
    private DormMapper dormMapper;

    @Override
    public Result add(Dorm dorm) {

        Dorm oldDorm = dormMapper.selectIsDelete(dorm.getId());
        if (oldDorm != null) {
            dorm.setIsDeleted(0);
            return update(dorm);
        }
        Building building = buildingService.getById(dorm.getBuildingId());
        if (building == null) {
            return Result.error("该宿舍楼不存在");
        }
        if (building.getGender() != dorm.getGender()) {
            return Result.error("宿舍性别与楼宇性别不匹配");
        }
        save(dorm);
        return Result.ok(null);

    }

    @Override
    public Result delete(Long id) {
        Dorm dorm = getById(id);
        if (dorm == null) {
            return Result.error("该宿舍不存在");
        }
        LambdaQueryWrapper<Student> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Student::getDormId, id);
        List<Student> students = studnetMapper.selectList(wrapper);
        if (students != null) {
            return Result.error("该宿舍有住户，不能删除");
        }
        removeById(id);
        return Result.ok(null);
    }

    @Override
    public Result update(Dorm dorm) {
        Long buildingId = dorm.getBuildingId();
        Building building = buildingService.getById(buildingId);
        if (building == null) {
            return Result.error("该宿舍楼不存在");
        }
        if (building.getGender() != dorm.getGender()) {
            return Result.error("宿舍性别与楼宇性别不匹配");
        }

        Dorm oldDorm;
        if (dorm.getIsDeleted() == 0) {
            oldDorm = dormMapper.selectIsDelete(dorm.getId());
        } else {
            oldDorm = getById(dorm.getId());
        }

        if (oldDorm == null) {
            return Result.error("该宿舍不存在");
        }
        if (oldDorm.getPersonNum() > dorm.getType()) {
            return Result.error("该宿舍类型不能小于当前住户数");
        }
        boolean b = updateById(dorm);
        System.out.println(dorm);
        System.out.println(b);
        return Result.ok(null);

    }

    @Override
    public Result select(Long id) {
        Dorm dorm = getById(id);
        if (dorm == null) {
            return Result.error("该宿舍不存在");
        }
        return Result.ok(dorm);
    }
}




