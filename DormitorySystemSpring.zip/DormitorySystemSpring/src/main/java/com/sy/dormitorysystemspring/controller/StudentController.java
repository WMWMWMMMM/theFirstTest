package com.sy.dormitorysystemspring.controller;

import com.sy.dormitorysystemspring.pojo.Student;
import com.sy.dormitorysystemspring.service.StudentService;
import com.sy.dormitorysystemspring.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/student")
public class StudentController {
    @Autowired
    private StudentService studentService;

    @RequestMapping("/add")
    public Result add(@RequestBody Student student) {
        return studentService.add(student);
    }

    @RequestMapping("/delete")
    public Result delete(Long id) {
        return studentService.deleteById(id);
    }

    @RequestMapping("/select")
    public Result select(Long id) {
        return studentService.select(id);
    }

    @RequestMapping("/update")
    public Result update(@RequestBody Student student) {
        return studentService.myUpdate(student);
    }
}
