package com.sy.dormitorysystemspring.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sy.dormitorysystemspring.mapper.StudentMapper;
import com.sy.dormitorysystemspring.pojo.Student;
import com.sy.dormitorysystemspring.pojo.Visitor;
import com.sy.dormitorysystemspring.service.VisitorService;
import com.sy.dormitorysystemspring.mapper.VisitorMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author 幻
 * @description 针对表【visitor】的数据库操作Service实现
 * @createDate 2024-05-18 03:29:52
 */
@Service
public class VisitorServiceImpl extends ServiceImpl<VisitorMapper, Visitor>
        implements VisitorService {
    @Autowired
    private VisitorMapper visitorMapper;
    @Autowired
    private StudentMapper studentMapper;

    @Override
    public boolean add(Visitor visitor) {
        Long studentId = visitor.getStudentId();
        if (studentId != null) {
            Student student = studentMapper.selectById(studentId);
            if (student == null) {
                return false;
            }
        }
        visitor.setId(null);
        visitorMapper.insert(visitor);
        return true;
    }

    @Override
    public boolean myUpdate(Visitor visitor) {
        Long studentId = visitor.getStudentId();
        if (studentId != null) {
            Student student = studentMapper.selectById(studentId);
            if (student == null) {
                return false;
            }
        }
        visitor.setId(null);
        visitorMapper.updateById(visitor);
        return true;
    }
}




