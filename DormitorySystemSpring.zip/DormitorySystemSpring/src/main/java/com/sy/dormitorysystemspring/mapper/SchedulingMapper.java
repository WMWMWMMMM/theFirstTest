package com.sy.dormitorysystemspring.mapper;

import com.sy.dormitorysystemspring.pojo.Scheduling;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 幻
* @description 针对表【scheduling】的数据库操作Mapper
* @createDate 2024-05-18 12:50:09
* @Entity com.sy.dormitorysystemspring.pojo.Scheduling
*/
public interface SchedulingMapper extends BaseMapper<Scheduling> {

}




