package com.sy.dormitorysystemspring.service;

import com.sy.dormitorysystemspring.pojo.Scheduling;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 幻
* @description 针对表【scheduling】的数据库操作Service
* @createDate 2024-05-18 12:50:09
*/
public interface SchedulingService extends IService<Scheduling> {

}
