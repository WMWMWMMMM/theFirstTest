package com.sy.dormitorysystemspring;

import com.sy.dormitorysystemspring.mapper.StudentMapper;
import com.sy.dormitorysystemspring.mapper.VisitorMapper;
import com.sy.dormitorysystemspring.pojo.Student;
import com.sy.dormitorysystemspring.pojo.Visitor;
import com.sy.dormitorysystemspring.service.StudentService;
import com.sy.dormitorysystemspring.service.VisitorService;
import com.sy.dormitorysystemspring.utils.Result;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;
import java.util.List;

@SpringBootTest
public class DormTestClass {
    @Autowired
    private StudentService studentService;
    @Autowired
    private VisitorMapper visitorMapper;
    @Autowired
    private StudentMapper studentMapper;
    @Autowired
    private VisitorService visitorService;
    @Test
    public void test1(){
        Result result = studentService.select(10001L);
        System.out.println(result);
    }
    @Test
    public void test2(){
        Result result = studentService.selectAll();
        System.out.println(result);
    }
    @Test
    public void test3(){
        List<Visitor> visitorList = visitorMapper.selectList(null);
        System.out.println(visitorList);
    }
    @Test
    public void teset4(){
        List<Student> studentList = studentMapper.selectList(null);
        System.out.println(studentList);
    }
    @Test
    public void test5(){
        Visitor visitor = new Visitor();
        visitor.setId(3L);
        visitor.setName("visitor3");
        visitor.setGender(0);
        visitor.setCause("the test");
        visitor.setStartDay(new Date());
        visitor.setEndDay(new Date());
        visitorService.add(visitor);
    }
    @Test
    public void test6(){
        Visitor visitor = new Visitor();
        visitor.setStudentId(11001L);
        visitor.setId(3L);
        visitor.setName("visitor3");
        visitor.setGender(0);
        visitor.setCause("the test");
        visitor.setStartDay(new Date());
        visitor.setEndDay(new Date());
        boolean result = visitorService.add(visitor);
        System.out.println(result);
    }
    @Test
    public void test7(){
        Student student = new Student();
        student.setProfessional("网络工程");
        studentMapper.update(student,null);
    }
    @Test
    public void test8(){
        Student student = new Student();
        student.setGender(1);
        Integer count = studentMapper.update(student,null);
        System.out.println(count);
    }
    @Test
    public void test9(){
        List<Student> studentList = studentMapper.selectList(null);
        for(Student student:studentList){
            student.setGender(1);
            studentMapper.updateById(student);
        }
        System.out.println("success");
    }

}
